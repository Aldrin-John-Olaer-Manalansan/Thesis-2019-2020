const _smart_home_serial_key_ = 'amFsZSc';


var path = require('path')
var fs = require('fs')
var express = require('express')
var https = require('https')
const WebSocket = require('ws');


var certOptions = {
  //key: fs.readFileSync(path.resolve('certs/server.key')),
  //cert: fs.readFileSync(path.resolve('certs/server.crt')),

}

// Web socket using ws
const server = https.createServer(certOptions);
//const global_server = https.createServer().listen(3000);

// Global

// Local
const LocalSocket = new WebSocket.Server({server});


// online
LocalSocket.on('connection', function connection(local) {
  var auth = false;
  var token;
  local.send(JSON.stringify({type:'handshake', status:'inactive'}));
  // message from client
  local.on('message', function incoming(message) {
    // Check if user follows standard
    console.log('received: %s', JSON.stringify(message));
    try{
    var user_request = JSON.parse(message);
    }
    catch(e){
      local.close()
      console.log('A user has been rejected');
      return;
    }
    //Handshake
    if(auth==false  ){
      //check validity
      if(!user_request.hasOwnProperty('key') &&!user_request.hasOwnProperty('type')){
        local.close();
        console.log('User does not comply');
      }
      if(user_request.key==_smart_home_serial_key_ && user_request.type=='serial' ){
        //Generate stamp
        var user_token = Date.now();
        token =(user_token);
        local.send(JSON.stringify({ type:'acknowledge', status:'Local', token:user_token  }));
        console.log('User has been acknowledged. Sending token: '+ user_token);
        auth=true;
        return;
      }
      else{
        console.log('User has the wrong key');
        local.close();}
        return;
     }
    //Check validity
    if(user_request.hasOwnProperty('status') && user_request.hasOwnProperty('type')){
      if(user_request.status==token){ local.send(handle(user_request)); return; }
      console.log('Token does not match!');
    }
  });
  // Active messaging where the server sends data automatically when file change occurs
  fs.watch(path.resolve('bridge/userdata.json'), {
    persistent: true
  }, function(event, filename) {
    if(auth==false) return;
    console.log(event + " event occurred on " + filename); /* Debug */
    //todo list
    //Detect file change
    //format the data
    //send to user
    ws.send(JSON.stringify({ type:'notify', status:'update' }))
  });
});




server.listen(443);


console.log('server start');









//// Methods



const handle = function(user_request){
  // Validate message if json

  // data init
  data = { type:'data', status:'OK' };
  // check for contents


  //to do listen//check for serial key
  //switch responses depending on request
  //return desired object

// User request are either commands or fetch

//fetch ------ register ------- remove -------
console.log('User has requested: ' + user_request.type );
  switch (user_request.type) {
    case 'fetch':
      data.type = 'data'
      data.status = getData();
      console.log('Sending home data');
      break;
    case 'register': // register appliance to masterlist
      //open user object
      user.serial

      break;
    case 'remove': //  remove appliance from masterlist
      //open user object
      user.serial
      break;
    case 'append': // Switch on or off
      //open user object
      break;
    default:
    data.status = 'Invalid Request';
  }

  return JSON.stringify(data);


}



function getData() {
  try {
    var userdata = JSON.parse(fs.readFileSync(path.resolve('bridge/userdata.json')));
  } catch (e) {
    console.log('Userdata is corrupted: ' +e );
    return 'No data';
  }
  //console.log(JSON.stringify(userdata));
  //Prepare Data
  //Get all possible addresses
  var logs=[];
  var consumption = {};
  userdata.appliance.map( sample =>{
    logs = logs.concat(Object.keys(sample.consumption));
  });
  logs.sort();
  logs = [...new Set(logs)];
  //Loop through addresses to all appliance
  // Add Their values to form a total
  //Append values to home total
  //Repeat for home data
  logs.map( log=>{
    //Check if home has the object
    consumption[log]={data:[], total:0};
    userdata.appliance.map( appliance=>{
      var total = 0;
      try {
        //appliance.consumption[log]['total']=total;
        appliance.consumption[log].data.map((val,i)=>{
          val = Math.round(val * 100) / 100

          if(consumption[log].data[i]==null){
            consumption[log].data[i]=val;
            total+=val;
          }
          else{
            consumption[log].data[i]+=val;
            total+=val;
          }
          consumption[log].data[i]=Math.round(consumption[log].data[i] * 100) / 100
          //appliance.consumption[log]['total']+=total.toFixed(2);
        });

        consumption[log]['total']+=total;

        appliance.consumption[log]['total']=total;
      } catch (e) { /* Skip */}

    });
  });
  logs.map( log=>{
    var total=0;
    consumption[log].data.map( val=>{
      total+=val;
    });
    consumption[log]['total']=total;
  })
  userdata['consumption']=consumption;

  console.log(JSON.stringify(userdata));
  return userdata;
};




//app.listen(3000, () => console.log(`Example app listening on port ${3000}!`))
